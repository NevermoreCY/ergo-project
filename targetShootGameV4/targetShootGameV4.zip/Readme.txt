To run the code, first adjest the input file name in the line " (let ((iport (open-input-file "targetShootObs1.txt")))" in targetShootGameV4.ergo.scm.

Then simply run "racket -l ergoExt -f targetShootGameV4.ergo.scm -m" in terminal.